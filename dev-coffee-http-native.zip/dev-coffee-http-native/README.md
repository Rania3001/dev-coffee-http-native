# Dev Coffee API

API REST em memória para gerenciamento de pedidos da cafeteria Dev Coffee, desenvolvida com os módulos nativos do Node.js, sem Express ou dependências externas.

## Requisitos

- Node.js 18 ou superior (recomendado).
- Não é necessário executar `npm install`, pois o projeto não possui dependências externas.

## Como executar

1. Abra a pasta do projeto no terminal.
2. Inicie o servidor:

```bash
npm start
```

Ou diretamente:

```bash
node server.js
```

O servidor ficará disponível em `http://localhost:3000`.

## Modelo de pedido

```json
{
  "id": 1,
  "client": "Nome do Cliente",
  "item": "Cappuccino",
  "status": "pendente"
}
```

Os status permitidos são `pendente`, `pronto` e `cancelado`. Os dados ficam armazenados apenas na memória e são perdidos quando o servidor é encerrado.

## Endpoints e exemplos cURL

### 1. Criar pedido — POST /orders

```bash
curl -i -X POST http://localhost:3000/orders \
  -H "Content-Type: application/json" \
  -d '{"client":"Ana","item":"Cappuccino"}'
```

Retorno esperado: `201 Created`, com o pedido criado e status inicial `pendente`.

### 2. Listar pedidos — GET /orders

```bash
curl -i http://localhost:3000/orders
```

### 3. Filtrar por status — GET /orders?status=pendente

```bash
curl -i "http://localhost:3000/orders?status=pendente"
```

### 4. Buscar pedido — GET /orders/:id

```bash
curl -i http://localhost:3000/orders/1
```

### 5. Atualizar status — PATCH /orders/:id/status

```bash
curl -i -X PATCH http://localhost:3000/orders/1/status \
  -H "Content-Type: application/json" \
  -d '{"status":"pronto"}'
```

Use somente `pendente`, `pronto` ou `cancelado`.

### 6. Excluir pedido — DELETE /orders/:id

```bash
curl -i -X DELETE http://localhost:3000/orders/1
```

Retorno esperado: `204 No Content`, sem corpo de resposta.

### 7. Testar rota inexistente

```bash
curl -i http://localhost:3000/rota-inexistente
```

Retorno esperado: `404 Not Found`, com mensagem JSON.

## Códigos HTTP utilizados

| Código | Significado |
|---|---|
| 200 | Consulta ou atualização realizada |
| 201 | Pedido criado |
| 204 | Pedido removido, sem corpo |
| 400 | Corpo JSON inválido ou dados inválidos |
| 404 | Pedido, rota ou método não encontrado/suportado |

## Decisões técnicas

- Servidor criado com `node:http`.
- URL e parâmetros de consulta tratados com `node:url`.
- Corpo de POST e PATCH lido pelos eventos `data` e `end`.
- `JSON.parse` protegido por `try/catch`.
- Respostas com conteúdo incluem `Content-Type: application/json; charset=utf-8`.
- A resposta 204 não envia corpo nem `Content-Type`.
- Não há persistência em banco de dados: os pedidos ficam em um array em memória.

## Autor

**Nome do estudante:** substitua este texto pelo seu nome completo antes de publicar.
