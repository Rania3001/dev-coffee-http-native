const http = require('node:http');
const { URL } = require('node:url');

const PORT = process.env.PORT || 3000;
const VALID_STATUSES = ['pendente', 'pronto', 'cancelado'];
const orders = [];
let nextId = 1;

// Envia respostas JSON com o cabeçalho exigido pela atividade.
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
  });
  res.end(JSON.stringify(data));
}

// Lê o corpo da requisição usando os eventos nativos da stream.
function readJsonBody(req, callback) {
  let body = '';
  const MAX_BODY_SIZE = 1024 * 1024; // 1 MB

  req.on('data', (chunk) => {
    body += chunk.toString('utf8');

    if (Buffer.byteLength(body, 'utf8') > MAX_BODY_SIZE) {
      callback(new Error('Corpo da requisição muito grande.'));
      req.destroy();
    }
  });

  req.on('end', () => {
    if (body.length === 0) {
      callback(new Error('O corpo da requisição não pode estar vazio.'));
      return;
    }

    try {
      const parsedBody = JSON.parse(body);
      callback(null, parsedBody);
    } catch {
      callback(new Error('JSON inválido no corpo da requisição.'));
    }
  });

  req.on('error', (error) => callback(error));
}

function findOrderById(id) {
  return orders.find((order) => order.id === id);
}

const server = http.createServer((req, res) => {
  const requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = requestUrl.pathname;
  const method = req.method;

  // GET /orders e GET /orders?status=pendente
  if (method === 'GET' && pathname === '/orders') {
    const statusFilter = requestUrl.searchParams.get('status');

    if (statusFilter && !VALID_STATUSES.includes(statusFilter)) {
      sendJson(res, 400, {
        error: 'Status inválido. Use: pendente, pronto ou cancelado.',
      });
      return;
    }

    const result = statusFilter
      ? orders.filter((order) => order.status === statusFilter)
      : orders;

    sendJson(res, 200, result);
    return;
  }

  // POST /orders
  if (method === 'POST' && pathname === '/orders') {
    readJsonBody(req, (error, body) => {
      if (res.writableEnded || res.destroyed) return;

      if (error) {
        sendJson(res, 400, { error: error.message });
        return;
      }

      if (
        !body ||
        typeof body.client !== 'string' ||
        typeof body.item !== 'string' ||
        body.client.trim() === '' ||
        body.item.trim() === ''
      ) {
        sendJson(res, 400, {
          error: 'Informe os campos client e item como textos não vazios.',
        });
        return;
      }

      const newOrder = {
        id: nextId++,
        client: body.client.trim(),
        item: body.item.trim(),
        status: 'pendente',
      };

      orders.push(newOrder);
      sendJson(res, 201, newOrder);
    });
    return;
  }

  // Rotas que recebem um ID numérico: /orders/:id ou /orders/:id/status
  const statusMatch = pathname.match(/^\/orders\/(\d+)\/status$/);
  const orderMatch = pathname.match(/^\/orders\/(\d+)$/);

  // PATCH /orders/:id/status
  if (method === 'PATCH' && statusMatch) {
    const id = Number(statusMatch[1]);
    const order = findOrderById(id);

    if (!order) {
      sendJson(res, 404, { error: `Pedido ${id} não encontrado.` });
      return;
    }

    readJsonBody(req, (error, body) => {
      if (res.writableEnded || res.destroyed) return;

      if (error) {
        sendJson(res, 400, { error: error.message });
        return;
      }

      if (!body || !VALID_STATUSES.includes(body.status)) {
        sendJson(res, 400, {
          error: 'Status inválido. Use: pendente, pronto ou cancelado.',
        });
        return;
      }

      order.status = body.status;
      sendJson(res, 200, order);
    });
    return;
  }

  // GET /orders/:id
  if (method === 'GET' && orderMatch) {
    const id = Number(orderMatch[1]);
    const order = findOrderById(id);

    if (!order) {
      sendJson(res, 404, { error: `Pedido ${id} não encontrado.` });
      return;
    }

    sendJson(res, 200, order);
    return;
  }

  // DELETE /orders/:id
  if (method === 'DELETE' && orderMatch) {
    const id = Number(orderMatch[1]);
    const index = orders.findIndex((order) => order.id === id);

    if (index === -1) {
      sendJson(res, 404, { error: `Pedido ${id} não encontrado.` });
      return;
    }

    orders.splice(index, 1);
    res.writeHead(204);
    res.end();
    return;
  }

  // Qualquer rota ou combinação de método/rota não prevista.
  sendJson(res, 404, {
    error: 'Rota não encontrada ou método HTTP não permitido.',
  });
});

server.listen(PORT, () => {
  console.log(`Dev Coffee API rodando em http://localhost:${PORT}`);
});
